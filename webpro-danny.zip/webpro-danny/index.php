<?php 

    include 'hal-admin/koneksi.php';

?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="hal-admin/css/tampilan.css">

    <title>Online Shop</title>

    <link rel="shortcut icon" href="hal-admin/img/logo.png" type="image/x-icon">

</head>

<body>

    <!-- As a link -->
    <nav class="navbar navbar-dark bg-dark">
        <a class="navbar-brand" href="index.php">
            <img src="hal-admin/img/logo.png" alt="LOGO WEB" width='30'> <b>Online Shop</b>
        </a>

        <form class="form-inline" action="?hal=produk-keyword" method="post">
            <input id="sandi" name="sandi" class="form-control mr-sm-2" type="search" placeholder="Kata Kunci" aria-label="Search">
            <button class="btn btn-primary my-2 my-sm-0" type="submit">Cari</button>
        </form>
    </nav>


    <div class="container-fluid badan-depan">
        <div class="row">
            <div class="col-2">
                <?php 
            include 'fungsional/menu-kiri.php';
          ?>
            </div>

            <div class="col-10">
                <?php 
            include 'fungsional/panggil-halaman.php';
          ?>
            </div>
        </div>

    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>

  
   <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
   <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


    <script>
      $(document).ready(function () 
      {
        $("#sandi").autocomplete(
        {
          //source:'http://localhost/webpro/webpro-danny/fungsional/rekomen-produk.php'
          source: 'fungsional/rekomen-produk.php',
          select: function(event, ui)
          {
            event.prevenDefault();
            $("#sandi").val(ui.item.nama_produk);
          }
        });  
      });
    </script>

</body>

</html>