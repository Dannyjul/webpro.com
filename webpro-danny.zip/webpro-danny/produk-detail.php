<?php 

    $idp= $_GET['idp'];

    $sql= "SELECT * FROM `produk` 
            INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori 
            INNER JOIN user ON produk.id_user = user.id_user
            WHERE produk.id_produk = '$idp'
            ORDER BY produk.id_produk DESC";
    $que= mysqli_query($sambungan, $sql);
    $cek = mysqli_num_rows($que);

    if($cek>0)
    {
        while ($a = mysqli_fetch_array($que)) 
        {
            $idprod  = $a["id_produk"];
            $nmprod  = $a["nama_produk"];
            $katego  = $a["nama_kategori"];
            $harga   = $a["harga"];
            $foto    = $a["foto"];
            $username= $a["username"];
            $deskrip = $a["deskripsi"];

            $hargarp = "Rp ".number_format($harga, 0, ".", ".")." -";

            if ($foto==null)//jika foto belum diupload 
            {
                $gambar = "hal-admin/img/no.png";
            } 
            else 
            {
                $gambar = "hal-admin/produk-img/$foto.jpg";
            }

            echo
            "
                <h3>$nmprod</h3>

                <p align='right'>
                    <b>$katego</b>, diupload oleh $username
                </p>

                <center>
                    <img src='$gambar' alt='$nmprod' width='60%' height='270'>
                </center>

                <p>
                    $deskrip
                </p>

            ";
           
        }
    }
    else
    {
        echo
        "
            <h5>Artikel tidak tersedia...</h5>
        ";
    }


?>