<?php 

    $sandi = $_POST['sandi'];

    $sql= "SELECT * FROM `produk` 
            INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori 
            INNER JOIN user ON produk.id_user = user.id_user
            WHERE nama_produk LIKE '%$sandi%' OR
            kategori.nama_kategori LIKE '%$sandi%' OR
            harga LIKE '%$sandi%'
            ORDER BY produk.id_produk DESC";
    $que= mysqli_query($sambungan, $sql);
    $cek = mysqli_num_rows($que);

    echo
    "
      <h3>Pencarian untuk: '$sandi'</h3>
    ";

    if($cek>0)
    {
        echo
        "
            <p>Ditemukan sekitar: $cek produk</p>
        ";
        while ($a = mysqli_fetch_array($que)) 
        {
            $idprod  = $a["id_produk"];
            $nmprod  = $a["nama_produk"];
            $katego  = $a["nama_kategori"];
            $harga   = $a["harga"];
            $foto    = $a["foto"];
            $username= $a["username"];

            $hargarp = "Rp ".number_format($harga, 0, ".", ".")." -";

            if ($foto==null)//jika foto belum diupload 
            {
                $gambar = "hal-admin/img/no.png";
            } 
            else 
            {
                $gambar = "hal-admin/produk-img/$foto.jpg";
            }

            echo
            "
            <div class='card' style='width: 12rem; margin:7px; float:left;'>
                <img src='$gambar' class='card-img-top tinggi-gambar' alt='$nmprod'>
                <div class='card-body'>
                    <p class='card-title titel'>$nmprod</p>
                    <p class='card-text'>
                        <span class='kategori'>$katego</span>
                        <b class='harga'>$hargarp</b>
                    </p>
                    <a href='?hal=produk-detail&idp=$idprod' class='btn btn-primary'>Detail</a>
                </div>
            </div>
            ";
           
        }
    }
    else
    {
        echo
        "
            <h5>Produk tidak tersedia...</h5>
        ";
    }


?>