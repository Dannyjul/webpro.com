<h2>Edit Produk</h2>

<?php

    include "koneksi.php";

    $idp= $_GET['aidi'];

    if ($status=='Member') 
    {
        $sql= "SELECT * FROM `produk` 
            INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori 
            INNER JOIN user ON produk.id_user = user.id_user
            WHERE produk.id_user='$id_user'  AND produk.id_produk='$idp'
            ORDER BY produk.id_produk DESC";
    } 
    else //manager, admin bisa ngeliat semua
    {
        $sql= "SELECT * FROM `produk` 
            INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori 
            INNER JOIN user ON produk.id_user = user.id_user
            WHERE produk.id_produk='$idp'
            ORDER BY produk.id_produk DESC
            ";
    }

    $que= mysqli_query($sambungan, $sql);


    while ($a = mysqli_fetch_array($que)) 
    {
        $idprod = $a["id_produk"];
        $nmprod = $a["nama_produk"];
        $katego = $a["nama_kategori"];
        $harga  = $a["harga"];
        $idkete = $a["id_kategori"];
        $deskrip= $a["deskripsi"];
        $foto    = $a["foto"];

        if ($foto==null)//jika foto belum diupload 
        {
            $gambar = "<img src='img/no.png' width='100' height='100'>";
        } 
        else 
        {
            $gambar = "<img src='produk-img/$foto.jpg' width='100' height='100'>";
        }
    }

?>

<form class="form-produk" action="?hal=produk-ubah" method="post" enctype="multipart/form-data">

   <input type="hidden" name="aidi" required value="<?php echo"$idprod"; ?>">

    <p>
        Nama Produk: <br>
        <input type="text" name="nama" required value="<?php echo"$nmprod"; ?>">
    </p>

    <p>
        Harga: <br>
        <input type="number" name="harga" required value="<?php echo"$harga"; ?>">
    </p>

    <p>
        Kategori: <br>
        <select name="kategori" required>
            
            <?php 
                
                echo
                "
                <option value='$idkete'>$katego</option>
                ";

                $sql= "SELECT *FROM kategori";
                $que= mysqli_query($sambungan, $sql);
        
                while ($a = mysqli_fetch_array($que)) 
                {
                    $idkat = $a["id_kategori"];
                    $nmkat = $a["nama_kategori"];
        
                    echo
                    "
                    <option value='$idkat'>$nmkat</option>
                    ";
                }
            ?>
        </select>
    </p>

    <p>
        Deskripsi: <br>
        <textarea name="deskripsi" cols="30" rows="10"><?php echo"$deskrip"; ?></textarea>
    </p>

    <p>
        <?php echo"$gambar"; ?>
    </p>

    <p>
        Foto Produk: <br>
        <input type="file" name="foto">
    </p>

    <p>
        <input type="submit" value="SIMPAN">
    </p>

</form>