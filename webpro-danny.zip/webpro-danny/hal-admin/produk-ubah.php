<?php

    include "koneksi.php";

    $id   = $_POST['aidi'];
    $nama = $_POST['nama'];
    $harga= $_POST['harga'];
    $kat  = $_POST['kategori'];
    $desk = $_POST['deskripsi'];

    //foto
    $namafoto = $_FILES['foto']['name'];
    $lokasinya= $_FILES['foto']['tmp_name'];

    //acak nama foto
    $tglup= date("d-m-yh:i:s");
    $tglub= md5($tglup);
    $namabaru = "Foto-".$tglub;

    //session, buat menampilkan siapa yang upload produk
    //karna udah didefinisikan di index, jadi gak perlu session_start lagi


    //kondisi upload foto
    if (empty($namafoto)) //jika belum upload
    {
        $sql  = "UPDATE `produk` SET `nama_produk`= '$nama',
                                     `id_kategori`= '$kat',
                                     `deskripsi`= '$desk',
                                     `harga`= '$harga'
                 WHERE id_produk='$id'";
    } 
    else //jika udah upload
    {
        //memasukkan ke folder
        move_uploaded_file($lokasinya, "produk-img/$namabaru.jpg");
        $sql  = "UPDATE `produk` SET `nama_produk`= '$nama',
                                    `id_kategori`= '$kat',
                                    `deskripsi`= '$desk',
                                    `harga`= '$harga',
                                    `foto` = '$namabaru'
                WHERE id_produk='$id'";
    }

    $que  = mysqli_query($sambungan, $sql);

    if ($que) 
    {
        echo
        "
            <script>
                alert('Data telah diubah');
                window.location = '?hal=produk-data';
            </script>
        ";
    } 
    else 
    {
        echo
        "
            <script>
                alert('Gagal diubah');
                window.location = '?hal=produk-edit';
            </script>
        ";
    }
    

?>