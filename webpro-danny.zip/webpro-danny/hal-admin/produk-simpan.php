<?php

    include "koneksi.php";

    $nama = $_POST['nama'];
    $harga= $_POST['harga'];
    $kat  = $_POST['kategori'];
    $desk = $_POST['deskripsi'];

    //foto
    $namafoto = $_FILES['foto']['name'];
    $lokasinya= $_FILES['foto']['tmp_name'];

    //acak nama foto
    //$acak = md5($namafoto);
    $tglup= date("d-m-yh:i:s");
    $tglub= md5($tglup);
    $namabaru = "Foto-".$tglub;

    //session, buat menampilkan siapa yang upload produk
    //karna udah didefinisikan di index, jadi gak perlu session_start lagi


    //kondisi upload foto
    if (empty($namafoto)) //jika belum upload
    {
        $sql  = "INSERT INTO produk VALUES (null,'$nama', '$kat', '$desk', '$harga', '$id_user', null)";
    } 
    else //jika udah upload
    {
        //memasukkan ke folder
        move_uploaded_file($lokasinya, "produk-img/$namabaru.jpg");
        $sql  = "INSERT INTO produk VALUES (null,'$nama', '$kat', '$desk', '$harga', '$id_user', '$namabaru')";
    }

    $que  = mysqli_query($sambungan, $sql);

    if ($que) 
    {
        echo
        "
            <script>
                alert('Data telah disimpan');
                window.location = '?hal=produk-data';
            </script>
        ";
    } 
    else 
    {
        echo
        "
            <script>
                alert('Gagal disimpan');
                window.location = '?hal=produk-tambah';
            </script>
        ";
    }
    

?>