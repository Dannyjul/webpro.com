<h2>Data Produk</h2>


<a href="?hal=produk-tambah">Tambah Baru</a>

<table border="1" width="500" id="tabelku">
    <thead>
        <tr>
            <th>No.</th>
            <th>Foto</th>
            <th>Nama Produk</th>
            <th>Kategori</th>
            <th>Harga</th>
            <th>Pemilik</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
    <?php

        include "koneksi.php";

        //si member hanya bisa melihat produknya sendiri

        if ($status=='Member') 
        {
             $sql= "SELECT * FROM `produk` 
                    INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori 
                    INNER JOIN user ON produk.id_user = user.id_user
                    WHERE produk.id_user='$id_user' 
                    ORDER BY produk.id_produk DESC";
        } 
        else //manager, admin bisa ngeliat semua
        {
             $sql= "SELECT * FROM `produk` 
                    INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori 
                    INNER JOIN user ON produk.id_user = user.id_user
                    ORDER BY produk.id_produk DESC
                   ";
        }
        $que= mysqli_query($sambungan, $sql);

        $no = 1;
        while ($a = mysqli_fetch_array($que)) 
        {
            $idprod  = $a["id_produk"];
            $nmprod  = $a["nama_produk"];
            $katego  = $a["nama_kategori"];
            $harga   = $a["harga"];
            $foto    = $a["foto"];
            $username= $a["username"];

            if ($foto==null)//jika foto belum diupload 
            {
                $gambar = "<img src='img/no.png' width='100' height='100'>";
            } 
            else 
            {
                $gambar = "<img src='produk-img/$foto.jpg' width='100' height='100'>";
            }

            echo
            "
                <tr>
                    <td align='center'>$no</td>
                    <td>
                        <center>$gambar</center>
                    </td>
                    <td>$nmprod</td>
                    <td>$katego</td>
                    <td>$harga</td>
                    <td>$username</td>
                    <td align='center'>
                        <a href='?hal=produk-lihat&aidi=$idprod'>Lihat</a>
                        <a href='?hal=produk-edit&aidi=$idprod'>Edit</a>
                        <a href='produk-hapus.php&aidi=$idprod'>Hapus</a>
                    </td>
                </tr>
            ";
            $no++;
        }
        
    ?>
    </tbody>

</table>




<h5 style="margin-top:50px;">Cari Berdasarkan Kategori:</h5>

<b>
    <ul>
        <?php 
        
            include "koneksi.php";

            $sql= "SELECT *FROM kategori";
            $que= mysqli_query($sambungan, $sql);

            
            while ($a = mysqli_fetch_array($que)) 
            {
                $idkat = $a["id_kategori"];
                $nmkat = $a["nama_kategori"];

                echo
                "
                <li><a href='?hal=produk-kategori&idk=$idkat'>$nmkat</a></li>
                ";
            }

        ?>
    </ul>
</b>