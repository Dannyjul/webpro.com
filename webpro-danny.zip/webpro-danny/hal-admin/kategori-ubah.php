<?php

    include "koneksi.php";

    $idk  = $_POST['idk'];
    $nama = $_POST['nama'];

    $sql  = "UPDATE `kategori` SET `nama_kategori`='$nama' WHERE `id_kategori`='$idk'";
    $que  = mysqli_query($sambungan, $sql);

    if ($que) 
    {
        echo
        "
            <script>
                alert('Data telah diubah');
                window.location = 'kategori-data.php';
            </script>
        ";
    } 
    else 
    {
        echo
        "
            <script>
                alert('Gagal diubah');
                window.location = 'kategori-edit.php?aidi=$idk';
            </script>
        ";
    }
    

?>