<?php

    include "koneksi.php";

    $user = $_POST['username'];
    $pass = $_POST['password'];    

    $sql  = "SELECT *FROM user WHERE username='$user' AND password='$pass'";
    $que  = mysqli_query($sambungan, $sql);
    //hitung jumlah data di database
    $cek  = mysqli_num_rows($que);

    if ($cek>0)//jika data orang login ketemu di db 
    {

        //menyimpan data yang login ke session
        //pastikan namanya harus sama dengan yang diindex
        session_start();
        while ($a = mysqli_fetch_array($que)) 
        {
            //deklarasi sekalian simpan data
            $_SESSION['usermasuk_id']     = $a['id_user'];
            $_SESSION['usermasuk_status'] = $a['status'];
        }
        
        echo
        "
            <script>
                alert('Selamat Datang');
                window.location = 'index.php';
            </script>
        ";
    } 
    else 
    {
        echo
        "
            <script>
                alert('Maaf...anda tidak berhak masuk');
                window.location = 'index.php';
            </script>
        ";
    }
    

?>