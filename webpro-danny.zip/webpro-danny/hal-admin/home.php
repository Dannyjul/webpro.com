<h4>Selamat Datang, <span style='color:crimson;'><?php echo "$namauser"; ?></span></h4>

<div class="row">
    <div class="col-sm">
        <center>
            <img src="img/logo.png" alt="Logo Web" width="50%">
        </center>
    </div>

    <div class="col-sm">
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor omnis quasi eos quisquam vitae rerum cum reprehenderit cumque quae voluptatum sequi tenetur ut molestias totam distinctio quaerat, voluptas magnam nobis.
        </p>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor omnis quasi eos quisquam vitae rerum cum reprehenderit cumque quae voluptatum sequi tenetur ut molestias totam distinctio quaerat, voluptas magnam nobis.
        </p>
    </div>
</div>