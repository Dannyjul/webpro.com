<?php 
    //$status-->didapatkan di file index.php --> deklarasi sesionnya
    if ($status=='Manager')//usahakan sesuai database 
    {
        echo
        "
        <h6>Menu $status</h6>

        <nav class='nav flex-column navigasiku'>
            <li class='nav-item'>
                <!--?hal untuk diproses di panggil-halaman.php-->
                <a class='nav-link active' href='?hal=home'>Home</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link active' href='?hal=kategori-data'>Kategori</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link active' href='?hal=produk-data'>Produk</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link active' href='logout.php'>Logout</a>
            </li>
        </nav>
        ";
    } 
    else if($status=='Admin')
    {
        echo
        "
        <h6>Menu $status</h6>

        <nav class='nav flex-column navigasiku'>
            <li class='nav-item'>
                <!--?hal untuk diproses di panggil-halaman.php-->
                <a class='nav-link active' href='?hal=home'>Home</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link active' href='?hal=kategori-data'>Kategori</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link active' href='?hal=produk-data'>Produk</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link active' href='#'>Data User</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link active' href='logout.php'>Logout</a>
            </li>
        </nav>
        ";
    }
    else
    {
        echo
        "
        <h6>Menu $status</h6>

        <nav class='nav flex-column navigasiku'>
            <li class='nav-item'>
                <!--?hal untuk diproses di panggil-halaman.php-->
                <a class='nav-link active' href='?hal=home'>Home</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link active' href='?hal=kategori-data'>Kategori</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link active' href='?hal=produk-data'>Produk</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link active' href='#'>Profil</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link active' href='logout.php'>Logout</a>
            </li>
        </nav>
        ";
    }

?>