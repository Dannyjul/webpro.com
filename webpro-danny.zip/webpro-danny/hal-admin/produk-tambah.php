<h2>Tambah Produk</h2>
                                 <!--jika ada upload file tambahkan enctype="multipart/form-data"-->
<form class="form-produk" action="?hal=produk-simpan" method="post" enctype="multipart/form-data">

    <p>
        Nama Produk: <br>
        <input type="text" name="nama" required>
    </p>

    <p>
        Harga: <br>
        <input type="number" name="harga" required>
    </p>

    <p>
        Kategori: <br>
        <select name="kategori" required>
            <option value="">PILIH KATEGORI</option>
            <?php 
                include "koneksi.php";

                $sql= "SELECT *FROM kategori";
                $que= mysqli_query($sambungan, $sql);
        
                while ($a = mysqli_fetch_array($que)) 
                {
                    $idkat = $a["id_kategori"];
                    $nmkat = $a["nama_kategori"];
        
                    echo
                    "
                    <option value='$idkat'>$nmkat</option>
                    ";
                }
            ?>
        </select>
    </p>

    <p>
        Deskripsi: <br>
        <textarea name="deskripsi" cols="30" rows="10"></textarea>
    </p>

    <p>
        Foto Produk: <br>
        <input type="file" name="foto">
    </p>

    <p>
        <input type="submit" value="SIMPAN">
    </p>

</form>