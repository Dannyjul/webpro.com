<?php

    include "koneksi.php";

    //si member hanya bisa melihat produknya sendiri
    $idp= $_GET['aidi'];

    if ($status=='Member') 
    {
        $sql= "SELECT * FROM `produk` 
            INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori 
            INNER JOIN user ON produk.id_user = user.id_user
            WHERE produk.id_user='$id_user'  AND produk.id_produk='$idp'
            ORDER BY produk.id_produk DESC";
    } 
    else //manager, admin bisa ngeliat semua
    {
        $sql= "SELECT * FROM `produk` 
            INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori 
            INNER JOIN user ON produk.id_user = user.id_user
            WHERE produk.id_produk='$idp'
            ORDER BY produk.id_produk DESC
            ";
    }
    $que= mysqli_query($sambungan, $sql);

    $no = 1;
    while ($a = mysqli_fetch_array($que)) 
    {
        $idprod  = $a["id_produk"];
        $nmprod  = $a["nama_produk"];
        $katego  = $a["nama_kategori"];
        $harga   = $a["harga"];
        $foto    = $a["foto"];
        $username= $a["username"];
        $deskrip = $a["deskripsi"];

        if ($foto==null)//jika foto belum diupload 
        {
            $gambar = "<img src='img/no.png' width='60%' height='300'>";
        } 
        else 
        {
            $gambar = "<img src='produk-img/$foto.jpg' width='60%' height='300'>";
        }

        echo
        "
            <h2>$nmprod</h2>
            <p>$katego</p>

            <center>
                $gambar
            </center>

            <p>$deskrip</p>

            <a href=?hal=produk-data>Kembali</a>
        ";
        $no++;
    }
    
?>