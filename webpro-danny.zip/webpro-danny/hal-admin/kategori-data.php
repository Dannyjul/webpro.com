<h2>Data Kategori</h2>


<a href="?hal=kategori-tambah">Tambah Baru</a>

<table border="1" width="350">
    <tr>
        <th>No.</th>
        <th>Nama Kategori</th>
        <th>Aksi</th>
    </tr>

    <?php

        include "koneksi.php";

        $sql= "SELECT *FROM kategori";
        $que= mysqli_query($sambungan, $sql);

        $no = 1;
        while ($a = mysqli_fetch_array($que)) 
        {
            $idkat = $a["id_kategori"];
            $nmkat = $a["nama_kategori"];

            echo
            "
                <tr>
                    <td align='center'>$no</td>
                    <td>$nmkat</td>
                    <td align='center'>
                        <a href='?hal=kategori-edit&aidi=$idkat'>Edit</a>
                        <a href='?hal=kategori-hapus&aidi=$idkat'>Hapus</a>
                    </td>
                </tr>
            ";
            $no++;
        }
        
    ?>

</table>