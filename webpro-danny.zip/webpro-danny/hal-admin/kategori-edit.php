<h2>Edit Kategori</h2>

<?php

    include "koneksi.php";

    $idk= $_GET['aidi'];

    $sql= "SELECT *FROM kategori WHERE id_kategori='$idk'";
    $que= mysqli_query($sambungan, $sql);


    while ($a = mysqli_fetch_array($que)) 
    {
       
    }

?>

<form action="kategori-ubah.php" method="post">

    <input type="hidden" name="idk" value="<?php echo"$idk"; ?>">

    <p>
        Nama Kategori: <br>
        <input type="text" name="nama" required value="<?php echo"$nmkat"; ?>">
    </p>

    <p>
        <input type="submit" value="SIMPAN">
    </p>

</form>