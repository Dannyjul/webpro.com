<?php

    include "koneksi.php";

    $idk= $_GET['aidi'];

    $sql  = "DELETE FROM kategori WHERE id_kategori='$idk'";
    $que  = mysqli_query($sambungan, $sql);

    if ($que) 
    {
        echo
        "
            <script>
                alert('Data telah dihapus');
                window.location = 'kategori-data.php';
            </script>
        ";
    } 
    else 
    {
        echo
        "
            <script>
                alert('Gagal dihapus');
                window.location = 'kategori-data.php';
            </script>
        ";
    }
    

?>