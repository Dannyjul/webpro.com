<?php

    session_start();

    //menghapus
    session_unset($_SESSION['usermasuk_id']);
    session_unset($_SESSION['usermasuk_status']);
    
    //session_destroy();

    header('location:index.php');

?>