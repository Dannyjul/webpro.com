<?php 

    //fungsinya file ini================
    //untuk menerima parameter ?hal yang kita pilih di navigasi kiri index.php

    //error_reporting(0);
    $halaman = $_GET['hal'];

    if (empty($halaman)) //jika halaman kosong
    {
        # biasanya saat web pertama kali dibuka
        include 'home.php';
    }
    else //jika kita ada pilih halaman menu
    {
        include "$halaman".'.php';
    }

?>