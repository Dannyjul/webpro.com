<?php 

    header("Access-Control-Allow-Origin:*");

    include "../hal-admin/koneksi.php";

    $sandi = $_POST['sandi'];

    $sql= "SELECT * FROM `produk` 
            INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori 
            INNER JOIN user ON produk.id_user = user.id_user
            WHERE nama_produk LIKE '%$sandi%' OR
            kategori.nama_kategori LIKE '%$sandi%' OR
            harga LIKE '%$sandi%'
            ORDER BY produk.id_produk DESC";
    $que= mysqli_query($sambungan, $sql);

    //$isidata = array();
    while ($a = mysqli_fetch_array($que)) 
    {
        $isidata[]=$a;
    }

    echo json_encode($isidata);

?>