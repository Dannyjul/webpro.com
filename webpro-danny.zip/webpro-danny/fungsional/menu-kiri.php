<ul class="nav flex-column">
  <?php

    $sql= "SELECT *FROM kategori";
    $que= mysqli_query($sambungan, $sql);

    $no = 1;
    while ($a = mysqli_fetch_array($que)) 
    {
        $idkat = $a["id_kategori"];
        $nmkat = $a["nama_kategori"];

        echo
        "
        <li class='nav-item'>
            <a class='nav-link active' href='#'>$nmkat</a>
        </li>
        ";
        $no++;
    }    
  ?>
</ul>